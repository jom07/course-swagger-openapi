import * as AST from "./ast"

export default function() {
  return {
    fn: { AST }
  }
}
